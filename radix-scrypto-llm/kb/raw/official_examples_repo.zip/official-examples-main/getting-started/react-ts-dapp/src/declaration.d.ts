declare namespace JSX {
  interface IntrinsicElements {
    "radix-connect-button": any;
  }
}

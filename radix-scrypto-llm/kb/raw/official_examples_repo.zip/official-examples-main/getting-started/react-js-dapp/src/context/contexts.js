import { createContext } from "react";

export const gatewayApiContext = createContext(null);
export const RdtContext = createContext(null);

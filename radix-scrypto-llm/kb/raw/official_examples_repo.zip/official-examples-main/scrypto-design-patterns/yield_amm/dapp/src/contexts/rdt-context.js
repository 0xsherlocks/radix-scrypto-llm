import { createContext } from "react";

export const RdtContext = createContext(null);

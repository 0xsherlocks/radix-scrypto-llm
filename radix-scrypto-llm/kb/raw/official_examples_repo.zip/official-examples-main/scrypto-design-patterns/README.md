# Scrypto Design Patterns

This section is designed to give you useful information about the Scrypto design patterns. These are designed to give a deeper understanding of the topic and are not meant to be read in order. You can jump to any example you like. For more basic examples, see the step-by-step section. For more full-stack examples, see the complete-reference-designs section.

## Table of Contents

1. [Blueprint Proxy](./blueprint-proxy)

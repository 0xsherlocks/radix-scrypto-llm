# `radix-common-derive`

Macros for declaring Decimal and PreciseDecimal constants, from the Radix DLT project.
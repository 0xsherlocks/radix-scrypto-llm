# `radix-common`

A library of common types and functions shared by all layers of the Radix stack, from the Radix DLT project.
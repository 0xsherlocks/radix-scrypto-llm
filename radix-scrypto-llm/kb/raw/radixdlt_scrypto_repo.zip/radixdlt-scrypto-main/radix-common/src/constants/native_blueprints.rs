// This file contains constants definitions used in native blueprints.

/// XRD amount put on worktop by free() method from Faucet blueprint.
pub const FAUCET_FREE_AMOUNT: u32 = 10000;

pub const SECONDS_IN_A_MINUTE: i64 = 60;
pub const SECONDS_IN_AN_HOUR: i64 = 3_600;
pub const SECONDS_IN_A_DAY: i64 = 86_400;

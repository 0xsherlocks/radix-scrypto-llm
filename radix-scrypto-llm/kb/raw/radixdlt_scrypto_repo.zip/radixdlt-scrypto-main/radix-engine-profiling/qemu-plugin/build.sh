#!/bin/bash
meson setup build
cd build
ninja

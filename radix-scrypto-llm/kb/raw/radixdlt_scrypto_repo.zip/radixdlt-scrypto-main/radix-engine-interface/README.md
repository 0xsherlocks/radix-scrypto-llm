# `radix-engine-interface`

The interface between system layer and VM layer, from the Radix DLT project.
use scrypto::prelude::*;

#[blueprint]
#[events(String, u32)]
mod blueprint {
    struct Club {}
    impl Club {}
}

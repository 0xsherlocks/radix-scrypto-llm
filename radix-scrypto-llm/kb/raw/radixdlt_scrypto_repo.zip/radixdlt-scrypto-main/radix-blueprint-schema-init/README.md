# `radix-blueprint-schema-init`

The model of blueprint schema initialization, from the Radix DLT project.

> [!IMPORTANT]  
> This crate is not supposed to be consumed directly. The interface may change as the code base evolves. Use at your own risk!
set -ex
cd "$(dirname "$0")"

cargo install --path ./radix-clis
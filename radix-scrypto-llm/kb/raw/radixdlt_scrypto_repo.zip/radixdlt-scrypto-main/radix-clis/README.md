# `radix-clis`

A collection of CLIs for developing, building and testing Scrypto code, from the Radix DLT project.
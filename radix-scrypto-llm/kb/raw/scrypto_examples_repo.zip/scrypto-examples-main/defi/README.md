# DeFi

This folder of DeFi examples are from a Radix hackathon, which is not peer reviewed or rigorously tested.

Hope they may have some useful concepts for you!
# Scrypto Core Blueprints
Here you will find examples that either represent foundational learning for Scrypto, or teach a single concept in the most limited scope possible.

If you're unsure where to start, try [hello-world](hello-world), [hello-nft](hello-nft) or [gumball-machine](gumball-machine) for the basics.
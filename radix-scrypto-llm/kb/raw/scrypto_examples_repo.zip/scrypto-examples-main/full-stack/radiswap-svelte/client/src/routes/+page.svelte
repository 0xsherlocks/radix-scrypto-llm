<script lang="ts">
	import { goto } from '$app/navigation';

	goto('/swap');
</script>

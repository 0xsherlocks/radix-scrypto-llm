<div>
	<slot />
</div>

<style lang="scss">
	div {
		min-width: 36rem;
		padding: 1rem 2rem;
		border: 1.5px solid #000;
		border-radius: 0.25rem;
	}
</style>

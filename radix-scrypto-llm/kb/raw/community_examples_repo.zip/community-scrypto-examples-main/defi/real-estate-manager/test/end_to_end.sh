
#!/bin/bash

#set -x
set -e

source ./distribute_land.sh
source ./construct_and_demolish.sh
source ./divide_and_merge_land.sh
source ./buy_sell_etc.sh

logg "Now you have completed the RealEstateService blueprint showcase, thanks for your time"
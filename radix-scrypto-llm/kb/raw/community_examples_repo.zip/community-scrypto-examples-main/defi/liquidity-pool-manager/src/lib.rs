use scrypto::prelude::*;

mod _flashloanpool;
mod _flashloanservice;
mod _poolmanager;

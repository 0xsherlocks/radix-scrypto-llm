// A simple blueprint for creating tokens, where the tokens a user has made are kept track of via a badge.

mod token_creator;
mod user;
